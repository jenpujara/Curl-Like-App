# Router

You can either use the precompiled distributions for Windows, Linux or MacOS.
Or build from source code by yourself.

1. Use the binary
Run `./router --help` for the usage.

2. Compile from source
 - Install Go (1.7 or later)
 - Run `go build router.go`

If you found any issue, please report. Thank you.
